package com.itheima.web.servlet.old;

import com.alibaba.fastjson.JSON;
import com.itheima.pojo.Brand;
import com.itheima.service.BrandService;
import com.itheima.service.impl.BrandServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

// @WebServlet("/selectAllServlet")
public class SelectAllServlet extends HttpServlet {

    // 通过多态获取 service 对象
    private BrandService brandService = new BrandServiceImpl();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 调用 service 返回
        List<Brand> brands = brandService.selectAll();
        // 转换成 JSON 串
        String jsonString = JSON.toJSONString(brands);
        // 响应 JSON 数据
        response.setContentType("text/json;charset=utf-8");
        response.getWriter().write(jsonString);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
